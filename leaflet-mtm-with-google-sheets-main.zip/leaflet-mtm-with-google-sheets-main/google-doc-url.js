// paste in your published Google Sheets URL from the browser address bar
var googleDocURL = 'https://docs.google.com/spreadsheets/d/1Uh4khylvGQXegf22VDY-WvX7Y08Xbf9frta_xoXJfvI/edit?gid=0#gid=0';

// insert your own Google Sheets API key from https://console.developers.google.com
var googleApiKey = 'AIzaSyBzVRsnkKxpCCJCo0MvzyhJyaTAJfgMMkk';
