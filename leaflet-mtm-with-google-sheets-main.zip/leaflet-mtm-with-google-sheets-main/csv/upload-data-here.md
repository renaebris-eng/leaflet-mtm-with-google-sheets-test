Option: upload your Google Sheets data in separate CSV files here, as described in https://handsondataviz.org/leaflet-maps-with-google-sheets/
